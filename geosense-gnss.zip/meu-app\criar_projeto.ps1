# Script para criar a estrutura do projeto GeoSense GNSS e compactar em .zip

$projectName = "geosense-gnss"
$outputZip = "$projectName.zip"

if (Test-Path $outputZip) { Remove-Item $outputZip }

# Cria pastas
New-Item -ItemType Directory -Force -Path ".github/workflows" | Out-Null

# ----- index.html -----
$html = @'
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>GeoSense GNSS</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css" />
    <style>
        /* SEU CSS COMPLETO AQUI */
        body { margin:0; padding:0; }
        #map { width:100vw; height:100vh; }
    </style>
</head>
<body>
    <div id="map"></div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/@turf/turf@6.5.0/turf.min.js"></script>
    <script>
        // SEU JAVASCRIPT COMPLETO AQUI
        console.log("GeoSense rodando!");
    </script>
</body>
</html>
'@
# ATENÇÃO: aqui você deve colocar TODO o conteúdo do seu index.html original.
# Como ele é muito grande, recomendo copiar manualmente ou usar o conteúdo que eu forneci na resposta anterior.
# Por questões de tamanho, estou resumindo, mas você pode pegar o HTML completo que já tem.

# Por enquanto, vou criar um index.html básico para demonstrar.
$html = Get-Content -Path ".\index.html" -Raw -ErrorAction SilentlyContinue
if (-not $html) {
    $html = @"
<!DOCTYPE html>
<html><head><title>GeoSense</title></head><body><h1>Coloque seu código aqui</h1></body></html>
"@
}
$html | Out-File -Encoding utf8 -FilePath "index.html"

# ----- package.json -----
@"
{
  "name": "geosense-gnss",
  "version": "1.0.0",
  "description": "App de coleta geoespacial",
  "main": "index.html",
  "scripts": {
    "sync": "npx cap sync",
    "open:android": "npx cap open android"
  },
  "dependencies": {
    "@capacitor/android": "^5.0.0",
    "@capacitor/core": "^5.0.0"
  },
  "devDependencies": {
    "@capacitor/cli": "^5.0.0"
  }
}
"@ | Out-File -Encoding utf8 -FilePath "package.json"

# ----- capacitor.config.json -----
@"
{
  "appId": "com.seudominio.geosense",
  "appName": "GeoSense GNSS",
  "webDir": "."
}
"@ | Out-File -Encoding utf8 -FilePath "capacitor.config.json"

# ----- .gitignore -----
@"
android/
ios/
node_modules/
*.apk
*.aab
dist/
"@ | Out-File -Encoding utf8 -FilePath ".gitignore"

# ----- README.md -----
@"
# GeoSense GNSS

App de coleta geoespacial. Compila APK via GitHub Actions.

## Build automático

Ao fazer push para a branch `main`, o GitHub Actions gera um APK de depuração.

## Desenvolvimento local

\`\`\`
npm install
npx cap add android
npx cap sync
npx cap open android
\`\`\`
"@ | Out-File -Encoding utf8 -FilePath "README.md"

# ----- build.yml -----
@"
name: Build Android APK

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20
      - name: Setup Java
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'
      - name: Install dependencies
        run: npm install
      - name: Init Capacitor
        run: npx cap init GeoSense GNSS com.seudominio.geosense --web-dir .
      - name: Add Android
        run: npx cap add android
      - name: Sync
        run: npx cap sync
      - name: Build APK
        run: |
          cd android
          chmod +x gradlew
          ./gradlew assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: app-debug
          path: android/app/build/outputs/apk/debug/app-debug.apk
"@ | Out-File -Encoding utf8 -FilePath ".github/workflows/build.yml"

# ----- Compactar -----
Compress-Archive -Path "." -DestinationPath $outputZip -Force

Write-Host "✅ Zip criado: $outputZip"